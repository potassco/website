"""
Functions and classes for symbol manipulation.

Examples
--------

```python
>>> from clingo.core import Library
>>> from clingo.symbol import Function, Number, parse_term
>>>
>>> lib = Library()
>>>
>>> num = Number(lib, 42)
>>> num.number
42
>>> fun = Function(lib, "f", [num])
>>> fun.name
'f'
>>> [ str(arg) for arg in fun.arguments ]
['42']
>>> parse_term(lib, str(fun)) == fun
True
>>> parse_term(lib, 'p(1+2)')
p(3)
```
"""

import enum
import typing
from collections.abc import Sequence

from clingo.core import Library

__all__: list[str] = [
    "Function",
    "Infimum",
    "Number",
    "String",
    "Supremum",
    "Symbol",
    "SymbolType",
    "Tuple_",
    "parse_term",
]

def Function(
    lib: Library,
    name: str,
    arguments: Sequence[Symbol] = [],
    is_positive: bool = True,
) -> Symbol:
    """
    Construct a function symbol.

    This includes constants and tuples. Constants have an empty argument list and
    tuples have an empty name. Functions can represent classically negated atoms.
    Argument `clingo.symbol.Symbol.is_positive` has to be set to `False` to
    represent such atoms.

    Args:
        lib: A library object to store the function in.
        name: The name of the function.
        arguments: The arguments in the form of a list of symbols.
        is_positive: Whether the function is positive.

    Returns:
        The constructed function symbol.
    """

def Number(lib: Library, number: int, /) -> Symbol:
    """
    Construct a numeric symbol given a number.

    Args:
        lib: A library object to store the number in.
        number: The given number.

    Returns:
        The constructed number symbol.
    """

def String(lib: Library, string: str, /) -> Symbol:
    """
    Construct a string symbol given a string.

    Args:
        lib: A library object to store the string in.
        string: The given string.

    Returns:
        The constructed string symbol.
    """

def Tuple_(lib: Library, arguments: Sequence[Symbol], /) -> Symbol:
    """
    Construct a tuple symbol.

    This is a shortcut for `Function(lib, "", arguments)`.

    Args:
        lib: A library object to store the tuple in.
        arguments: The arguments in form of a list of symbols.

    Returns:
        The constructed tuple symbol.
    """

def parse_term(lib: Library, string: str, /) -> Symbol:
    """
    Parse the given string using clingo's term parser for ground terms.

    The function also evaluates arithmetic functions.

    Args:
        lib: A library object to store parsed symbols in.
        string: The string to be parsed.

    Returns:
        The parsed symbol.
    """

Infimum: Symbol
"""
The infimum symbol `#inf`.
"""
Supremum: Symbol
"""
The supremum symbol `#sup`.
"""

class SymbolType(enum.IntEnum):
    """
    Enumeration of symbols types.
    """

    Function = 5
    """
    A function symbol, for exmample `f(1,2)` or `g`.
    """
    Infimum = 2
    """
    The infimum symbol `#inf`.
    """
    Number = 0
    """
    A number symbol, for example `42` or `-1`.
    """
    String = 3
    """
    A string symbol, for example `"hello"`.
    """
    Supremum = 1
    """
    The supremum symbol `#sup`.
    """
    Tuple = 4
    """
    A tuple symbol, for example `(1,2)` or `()`.
    """

class Symbol:
    """
    Represents a clingo symbol.

    This includes `#inf` and `#sup`, numbers, strings, tuples, functions (including
    constants with `len(arguments) == 0`.

    Symbol objects implement Python's rich comparison operators and are ordered
    like in clingo. They can also be used as keys in dictionaries. Their string
    representation corresponds to their clingo representation.

    Note that this class does not have a constructor. Instead there are the
    preconstructed symbols `clingo.symbol.Infimum` and `clingo.symbol.Supremum` and
    the functions `clingo.symbol.Number`, `clingo.symbol.String`,
    `clingo.symbol.Tuple_`, and `clingo.symbol.Function` to construct symbol
    objects.
    """

    def __eq__(self, value: object, /) -> bool:
        """
        Compare with another object for equality.

        Args:
            value: The object to compare with.

        Returns:
            Whether the two objects are equal.
        """

    def __ne__(self, value: object, /) -> bool:
        """
        Compare with another object for inequality.

        Args:
            value: The object to compare with.

        Returns:
            Whether the two objects are not equal.
        """

    def __hash__(self) -> int:
        """
        Compute a hash value for this symbol.

        Returns:
            The hash value.
        """

    def __ge__(self, value: object, /) -> bool:
        """
        Compare with another object for greater than or equal.

        Args:
            value: The object to compare with.

        Returns:
            Whether this symbol is greater than or equal to the other object.
        """

    def __gt__(self, value: object, /) -> bool:
        """
        Compare with another object for greater than.

        Args:
            value: The object to compare with.

        Returns:
            Whether this symbol is greater than the other object.
        """

    def __le__(self, value: object, /) -> bool:
        """
        Compare with another object for less than or equal.

        Args:
            value: The object to compare with.

        Returns:
            Whether this symbol is less than or equal to the other object.
        """

    def __lt__(self, value: object, /) -> bool:
        """
        Compare with another object for less than.

        Args:
            value: The object to compare with.

        Returns:
            Whether this symbol is less than the other object.
        """

    @typing.overload
    def match(self, name: str, /, arity: int = 0, is_positive: bool = True) -> bool:
        """
        Check if this is a function symbol with the given signature.

        Args:
            name: The name of the function.
            arity: The arity of the function.
            is_positive: Whether to match positive or negative signatures.

        Returns:
            Whether the function matches.
        """

    @typing.overload
    def match(self, arity: int, /) -> bool:
        """
        Check if this is a tuple symbol with the given arity.

        Args:
            arity: The arity of the function.

        Returns:
            Whether the tuple matches.
        """

    def match(self, *args, arity: int = 0, is_positive: bool = True) -> bool:
        """
        Check if this is a function or tuple symbol with the given signature.

        Args:
            name (str): The name of the function.
            arity: The arity of the function.
            is_positive: Whether to match positive or negative signatures.

        Returns:
            Whether the function or tuple matches.
        """

    @property
    def arguments(self) -> Sequence[Symbol]:
        """
        The list of arguments a function or tuple.
        """

    @property
    def arity(self) -> int:
        """
        The arity of a function or tuple.
        """

    @property
    def is_negative(self) -> bool:
        """
        Whether the symbol is negative, e.g., `-1` or `-p`.
        """

    @property
    def is_positive(self) -> bool:
        """
        Whether the symbol is positive, e.g., `1` or `p`.
        """

    @property
    def name(self) -> str:
        """
        The name of a function symbol.
        """

    @property
    def number(self) -> int:
        """
        The numeric value of a number symbol.
        """

    @property
    def signature(self) -> tuple[str, int, bool] | None:
        """
        The signature of function symbols.

        The Boolean in the signature is True if the associated symbol is positive.
        """

    @property
    def string(self) -> str:
        """
        The string value of a string symbol.
        """

    @property
    def type(self) -> SymbolType:
        """
        The type of the symbol.
        """
